import json
import boto3
from flask import Flask, request, render_template, redirect, session, url_for

application = Flask(__name__)
application.secret_key = "secret123"

@application.route("/")
def index():
    pizzas = [
        {"name": "Peppy Paneer", "image": "peppy_paneer", "price": 250},
        {"name": "Farm House", "image": "farm_house", "price": 200},
        {"name": "Mexican Green Wave", "image": "mexican_greenwave", "price": 200},
        {"name": "Veggie Paradise", "image": "veggie_paradise", "price": 270},
        {"name": "Paneer Makhani", "image": "paneer_makhani", "price": 350},
        {"name": "Plain Cheese", "image": "plain_cheese", "price": 150}
    ]
    cart_items = session.get("cart", [])
    global_quantity = sum(item["quantity"] for item in cart_items)
    return render_template("index.html", pizzas=pizzas, global_quantity=global_quantity)

@application.route("/add-to-cart", methods=["POST"])
def add_to_cart():
    pizza_name = request.form.get("pizza_name")
    pizza_image = request.form.get("pizza_image")
    pizza_price = int(request.form.get("pizza_price"))
    pizza_quantity = int(request.form.get("pizza_quantity"))
    
    cart_items = {
        "name": pizza_name,
        "image": pizza_image,
        "price": pizza_price,
        "quantity": pizza_quantity
    }
    if "cart" not in session:
        session["cart"] = []

    found = False
    for item in session["cart"]:
        if item["name"] == pizza_name:
            item["price"] += pizza_price
            item["quantity"] += pizza_quantity
            found = True
            break

    if not found:
        session["cart"].append(cart_items)

    session.modified = True
    return redirect(url_for("index"))
    
@application.route("/confirm")
def confirm():
    cart_items = session.get("cart", [])
    global_quantity = sum(item["quantity"] for item in cart_items)
    total_price = sum(item["price"] for item in cart_items)
    gst = round(total_price * 0.05)
    grand_total = total_price + gst
    
    return render_template(
        "confirm.html", 
        cart_items=cart_items, 
        global_quantity=global_quantity,
        total_price=total_price,
        gst=gst,
        grand_total=grand_total
    )

@application.route("/add-quantity", methods=["POST"])
def add_quantity():
    name = request.form["pizza_name"]
    price = int(request.form["pizza_price"])
    cart_items = session.get("cart", [])
    for item in cart_items:
        if item["name"] == name:
            item["price"] += price
            item["quantity"] += 1
            break
    session["cart"] = cart_items
    return redirect(url_for("confirm"))

@application.route("/subtract-quantity", methods=["POST"])
def substract_quantity():
    name = request.form["pizza_name"]
    price = int(request.form["pizza_price"])
    cart_items = session.get("cart", [])
    for item in cart_items:
        if item["name"] == name:
            item["price"] -= price
            item["quantity"] -= 1
            if item["quantity"] <= 0:
                cart_items.remove(item)
            break
    session["cart"] = cart_items
    return redirect(url_for("confirm"))

@application.route("/clear-cart", methods=["POST"])
def clear_cart():
    session.pop("cart", None)
    session.pop("price", None)
    session.pop("quantity", None)
    return redirect(url_for("index")) 

@application.route("/place-order", methods=["POST"])
def place_order():
    email = request.form["email"]
    address = request.form["address"]
    cart_items = session.get("cart", [])
    session["cart"] = []
    global_quantity = sum(item["quantity"] for item in cart_items)

    total_price = sum(item["price"] for item in cart_items)
    gst = round(total_price * 0.05)
    grand_total = total_price + gst

    order_data = {
        "email": email,
        "address": address,
        "cart": cart_items,
        "total": grand_total
    }
    message_body = json.dumps(order_data)

    sqs = boto3.client("sqs", region_name="ap-south-1")
    sqs.send_message (
        QueueUrl = "https://sqs.ap-south-1.amazonaws.com/992382676630/pizza-queue",
        MessageBody = message_body
    )

    return render_template (
        "ordered.html", 
        email = email, 
        address = address,
        global_quantity = global_quantity,   
    )

if __name__ == "__main__":
    application.run(debug=True)