import json
import extras as ex

def lambda_handler(event, context):
    action = event.get("action")
    email = event.get("email")
    token = event.get("token")

    if action == "register_user":
        if email in ex.get_items().keys():
            return {
                "statusCode": 200,
                "body": json.dumps({"status": "exists"})
            }
        ex.write_dynamo(email)
        ex.send_email(email)
        return {
            "statusCode": 200,
            "body": json.dumps({"status": "registered"})
        }
    
    if action == "unsubscribe_user":
        email = next((key for key, value in ex.get_items().items() if value == token), None)
        if email:
            ex.delete_dynamo(email, token)
            return {
            "statusCode": 200,
            "body": json.dumps({"status": "unsubscribed"})
            }
        else:
            return {
                "statusCode": 404,
                "body": json.dumps({"status": "missing"})
            }
        
    if action == "schedule_email":
        ex.schedule_email()
        print("Emails Sent!")
        return {
        "statusCode": 200,
        "body": json.dumps("Success")
        }
    else:
        return {
        "statusCode": 500,
        "body": json.dumps("Something went wrong")    
        }