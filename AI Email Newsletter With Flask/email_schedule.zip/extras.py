import boto3
import secrets
import yagmail
from google import genai
from dotenv import load_dotenv
import os

load_dotenv(".env")
dynamodb = boto3.client("dynamodb", region_name = "ap-south-1")

def run_ai():
    prompt = "Share an interesting space fact"
    client = genai.Client(api_key = os.getenv("API_KEY"))
    response = client.models.generate_content(
    model = "gemini-2.0-flash-exp",
    contents = prompt
    )
    return response.text

def get_items():
    response = dynamodb.scan(TableName="email_list")
    items = response.get("Items", [])
    result = {}
    for item in items:
        email = item.get("email", {}).get("S")
        token = item.get("token", {}).get("S")
        if email and token:
            result[email] = token
    return result


def write_dynamo(mail):
    token = secrets.token_hex(8)
    dynamodb.put_item(
        TableName = "email_list",
        Item = {
            "email": {"S": mail},
            "token": {"S": token}
        }
    )

def delete_dynamo(mail, token):
    dynamodb.delete_item(
        TableName = "email_list",
        Key = {
            "email": {"S": mail},
            "token": {"S": token}
        }
    )
  
def send_email(mail):
    token = get_items()[mail]
    if not token:
        print("User not registered")
    
    unsub = f"http://ai-newsletter101.ap-south-1.elasticbeanstalk.com/cancel?token={token}"
    yag = yagmail.SMTP(os.getenv("SENDER"), os.getenv("PASSWORD"))
    yag.send(
        to = "your_email@gmail.com",
        bcc = mail,
        subject = "New Space Facts for you!",
        contents = f"{run_ai()} \nClick here to unsubscribe: {unsub}"
    )

def schedule_email():
    mail_list = get_items().keys()
    for email in mail_list:
        send_email(email)