import json
import boto3
from flask import Flask, request, render_template

lambda_client = boto3.client("lambda", region_name="ap-south-1")

application = Flask(__name__)

@application.route("/")
def index():
    return render_template("index.html")

@application.route("/confirm", methods=["POST"])
def register_user():
    email = request.form.get("email")
    response = lambda_client.invoke(
        FunctionName = "lambda_function",
        InvocationType = "RequestResponse",
        Payload = json.dumps({
            "action": "register_user",
            "email": email
        })
    )
    payload_raw = response["Payload"].read()
    payload_dict = json.loads(payload_raw)

    body_str = payload_dict.get("body")
    if not body_str:
        return "Something went wrong: no body returned from Lambda", 500

    result = json.loads(body_str)

    if result.get("status") == "exists":
        return "Email already registered"
    elif result.get("status") == "registered":
        return render_template("confirm.html", email = email)
    else:
        return "Something went wrong", 500

@application.route("/cancel")
def unsubscribe():
    token = request.args.get("token")

    response = lambda_client.invoke(
        FunctionName = "lambda_function",
        InvocationType = "RequestResponse",
        Payload = json.dumps({
            "action": "unsubscribe_user",
            "token": token
        })
    )
    payload_raw = response["Payload"].read()
    payload_dict = json.loads(payload_raw)

    body_str = payload_dict.get("body")
    if not body_str:
        return "Something went wrong: no body returned from Lambda", 500

    result = json.loads(body_str)

    if result.get("status") == "unsubscribed":
        return render_template("cancel.html", token = token)
    elif result.get("status") == "missing":
        return "Invalid or missing token"
    else:
        return "Something went wrong", 500

if __name__ == "__main__":
    application.run(debug=True)