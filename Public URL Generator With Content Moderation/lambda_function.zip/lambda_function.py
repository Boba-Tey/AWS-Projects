import base64
import boto3
import json
import secrets
import os

def content_moderation(file_data):
    rekognition = boto3.client("rekognition", region_name="ap-south-1")
    response = rekognition.detect_moderation_labels(
        Image={"Bytes": file_data}, MinConfidence=60
    )
    inappropriate_content = []

    explicit_list = {
        "Explicit Nudity",
        "Graphic Male Nudity",
        "Graphic Female Nudity",
        "Sexual Activity",
        "Pornography",
        "Hate Symbols",
        "Violence",
        "Self Harm",
        "Child Exploitation"
    }

    for label in response.get('ModerationLabels', []):
        label_name = label["Name"]
        label_parent_name = label.get("ParentName")
        if label_name in explicit_list:
            inappropriate_content.append(label_name)
        elif label_parent_name and label_parent_name in explicit_list:
            inappropriate_content.append(label_parent_name)
    
    return inappropriate_content

def s3_url_maker(filename, file_data, content_type):
    unique_id = secrets.token_hex(16)
    file_extension = os.path.splitext(filename)[1]
    new_filename = unique_id + file_extension

    s3 = boto3.client("s3", region_name="ap-south-1")
    s3.put_object(
        Bucket="public-url-store101",
        Key=new_filename,
        Body=file_data,
        ContentType=content_type
    )
    s3_url = f"https://public-url-store101.s3.amazonaws.com/{new_filename}"
    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*", 
            "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
            "Access-Control-Allow-Headers": "*"
        },
        "body": json.dumps({"url": s3_url})
    }

def lambda_handler(event, context):
    if event.get("requestContext", {}).get("http", {}).get("method") == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
                "Access-Control-Allow-Headers": "*"
            },
            "body": json.dumps({"message": "CORS preflight OK"})
        }

    try:
        method = event["requestContext"]["http"]["method"]
        if method == "POST":
            body = json.loads(event["body"])
            file_data = base64.b64decode(body["imageBase64"])
            filename = body["filename"]
            content_type = body["content_type"]

            inappropriate_content = content_moderation(file_data)
            if inappropriate_content:
                return {
                    "statusCode": 400,
                    "headers": {
                        "Content-Type": "application/json",
                        "Access-Control-Allow-Origin": "*"
                    },
                    "body": json.dumps({
                        "message": "Inappropriate content detected, Please try another image.",
                        "moderation_labels": list(set(inappropriate_content))
                    })
                }
            else:
                return s3_url_maker(filename, file_data, content_type)
        else:
            return {
                "statusCode": 405,
                "headers": {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                "body": json.dumps({"message": "Method Not Allowed"})
            }

    except Exception as e:
        import traceback
        traceback.print_exc()
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({"message": "Internal server error", "error": str(e)})
        }
