import json
import yagmail
import os
from dotenv import load_dotenv

load_dotenv(".env")

def order_confirm(address, cart, total):
    cart_html = "\n".join(cart)
    return f"""
<html>
    <body style="font-family: Arial; color: #333;">
        <h2>🍕 Thank you for ordering from Domino's!</h2>
        <p><strong>Delivery Address:</strong> {address}</p>
        <h3>Your Order:</h3>
        {cart_html}
        <p><strong>Total Amount:</strong> ₹{total} (including GST)</p>
        <p>Estimated delivery time: <em>30 minutes or less</em></p>
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSjsnv460UAYQSHUSYQPDIrVV7G3avjkQfdqg&s"/>
    </body>
</html>
"""

def send_mail(email, html_content):
    yag = yagmail.SMTP(os.getenv("SENDER"), os.getenv("PASSWORD"))
    yag.send(
        to = "noreply.funfactz@gmail.com",
        bcc = email,
        subject = "Your order has been placed!",
        contents = [html_content]
    )

def lambda_handler(event, context):
    for record in event["Records"]:
        body = json.loads(record["body"])
        email = body["email"]
        address = body["address"]
        total = body["total"]
        cart_items = body["cart"]

        cart_list = []
        for item in cart_items:
            name = item["name"]
            price = item["price"]
            quantity = item["quantity"]
            cart_list.append(f"X{quantity} {name}: ₹{price}")

        content = order_confirm(address, cart_list, total)
        send_mail(email, content)